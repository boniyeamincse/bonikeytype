# 🚀 Deployment

## Overview

| Layer | Recommended Platform |
|---|---|
| Frontend | Vercel or Netlify |
| Backend | VPS (DigitalOcean / Render) or Docker |
| Database | Supabase, AWS RDS, or DigitalOcean Managed PG |
| WebSocket | Same server as backend (Socket.io co-hosted) |

---

## Frontend — Vercel

1. Push `frontend/` to a GitHub repo
2. Connect repo to [vercel.com](https://vercel.com)
3. Set root directory to `frontend`
4. Add environment variables in Vercel dashboard:

```
VITE_API_URL=https://api.bonikeytype.com/api
VITE_SOCKET_URL=https://api.bonikeytype.com
```

5. Deploy. Vercel auto-deploys on every push to `main`.

---

## Backend — Docker (VPS)

### Dockerfile

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY src/ ./src/
EXPOSE 3000
CMD ["node", "src/server.js"]
```

### docker-compose.yml

```yaml
version: '3.8'
services:
  api:
    build: ./backend
    ports:
      - "3000:3000"
    environment:
      DB_HOST: db
      DB_PORT: 5432
      DB_USER: postgres
      DB_PASSWORD: ${DB_PASSWORD}
      DB_NAME: bonikeytype
      JWT_SECRET: ${JWT_SECRET}
      FRONTEND_URL: ${FRONTEND_URL}
    depends_on:
      - db

  db:
    image: postgres:15
    environment:
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: bonikeytype
    volumes:
      - pgdata:/var/lib/postgresql/data

volumes:
  pgdata:
```

### Deploy to VPS

```bash
# On your VPS
git clone https://github.com/your-username/bonikeytype.git
cd bonikeytype
cp .env.example .env
# Fill in .env values
docker-compose up -d
```

---

## Database — Supabase (Recommended for Quick Start)

1. Create a project at [supabase.com](https://supabase.com)
2. Go to **SQL Editor** → paste and run migration SQL from `backend/db/migrations/`
3. Copy the connection string from **Settings → Database**
4. Set in backend `.env`:

```env
DB_HOST=db.xxxxxxxxxxxx.supabase.co
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=your_supabase_password
DB_NAME=postgres
```

---

## Nginx Reverse Proxy (Optional)

Route traffic from port 80/443 to backend on port 3000:

```nginx
server {
    listen 80;
    server_name api.bonikeytype.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';    # Required for Socket.io
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

> `Upgrade` and `Connection` headers are required for WebSocket (Socket.io) support through Nginx.

---

## SSL / HTTPS

Use **Let's Encrypt** with Certbot:

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d api.bonikeytype.com
```

---

## Environment Variables Summary

| Variable | Frontend | Backend |
|---|---|---|
| `VITE_API_URL` | ✅ | — |
| `VITE_SOCKET_URL` | ✅ | — |
| `DB_HOST` | — | ✅ |
| `DB_USER` | — | ✅ |
| `DB_PASSWORD` | — | ✅ |
| `DB_NAME` | — | ✅ |
| `JWT_SECRET` | — | ✅ |
| `FRONTEND_URL` | — | ✅ |
| `PORT` | — | ✅ |
